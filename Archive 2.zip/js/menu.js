//resize logo when scroll*/

$(window).scroll(function() {
	if ($(this).scrollTop() > 20){  
		$('.logo img').css("width","98px").addClass('rezie-logo');;
		$('.logo-smp img').css("width","44px").addClass('rezie-logo');
	}
	else{
		$('.logo img').css("width","196px").addClass('rezie-logo');;
		$('.logo-smp img').css("width","88px").addClass('rezie-logo');;
	}
});

$(document).ready(function(){
	/*toggle navigator smartphone*/
	$(".menu-icon").click(function(){
		$("#nav-smp").toggle();
	});
	/*accordion menu*/
	$("li.accordion").click(function() {
		$(this).toggleClass("accIcon");
		var accd = $(this).next();
		if(accd.css("display")==="none"){
			accd.css("display","block");
		}else{
			accd.css("display","none");
		}
	});
});
/*animated menu*/
function animateMenu(x) {
    x.classList.toggle("change");
}